/* ==========================================================================
   宵町横丁 · 夜祭小街 — interactions
   ========================================================================== */
(() => {
  'use strict';

  const app = document.getElementById('app');
  const viewport = document.getElementById('viewport');
  const camera = document.getElementById('camera');
  const STAGE = 1600;
  const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  /* --------------------------------------------------------------------------
     相机
     -------------------------------------------------------------------------- */
  let vw = 0, vh = 0, baseScale = 1;
  const cam = { x: 800, y: 820, z: 1 };

  function measure() {
    vw = window.innerWidth;
    vh = window.innerHeight;
    baseScale = Math.max(vw, vh) / STAGE;
  }
  const clamp = (v, a, b) => v < a ? a : v > b ? b : v;

  function paint(instant, ms) {
    const s = baseScale * cam.z;
    let tx = vw / 2 - cam.x * s;
    let ty = vh / 2 - cam.y * s;
    const sw = STAGE * s, sh = STAGE * s;
    tx = sw > vw ? clamp(tx, vw - sw, 0) : (vw - sw) / 2;
    ty = sh > vh ? clamp(ty, vh - sh, 0) : (vh - sh) / 2;
    camera.style.transition = instant ? 'none' : (ms ? `transform ${ms}ms cubic-bezier(.22,.61,.2,1)` : 'transform 1.05s cubic-bezier(.22,.61,.2,1)');
    camera.style.transform = `translate3d(${tx}px,${ty}px,0) scale(${s})`;
  }

  function focus(x, y, z, ms) {
    cam.x = x; cam.y = y; cam.z = z;
    paint(false, ms);
  }

  measure();
  paint(true);

  /* 开场：从灯笼特写拉到整条街 */
  if (!reduceMotion) {
    cam.x = 742; cam.y = 470; cam.z = 1.78;
    paint(true);
    requestAnimationFrame(() => {
      requestAnimationFrame(() => {
        cam.x = 800; cam.y = 820; cam.z = 1;
        paint(false, 2800);
      });
    });
    setTimeout(() => app.classList.add('is-ready'), 1700);
  } else {
    cam.x = 800; cam.y = 820; cam.z = 1;
    paint(true);
    app.classList.add('is-ready');
  }

  window.addEventListener('resize', () => {
    measure();
    paint(true);
  });

  /* 拖动看看 */
  let dragging = false, dragId = null, lastX = 0, lastY = 0, moved = 0;

  /* --------------------------------------------------------------------------
     声音（WebAudio 合成，无外部文件）
     -------------------------------------------------------------------------- */
  const audio = (() => {
    let ctx = null, noise = null, muted = false, ready = false;
    try { muted = localStorage.getItem('yoimachi-muted') === '1'; } catch (_) {}

    function ensure() {
      if (!ctx) {
        const AC = window.AudioContext || window.webkitAudioContext;
        if (!AC) return null;
        ctx = new AC();
        const len = ctx.sampleRate * 0.4;
        noise = ctx.createBuffer(1, len, ctx.sampleRate);
        const d = noise.getChannelData(0);
        for (let i = 0; i < len; i++) d[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / len, 2.2);
      }
      if (ctx.state === 'suspended') ctx.resume();
      ready = true;
      return ctx;
    }

    function env(gain, peak, attack, decay, at) {
      const g = gain.gain;
      g.setValueAtTime(0.0001, at);
      g.exponentialRampToValueAtTime(peak, at + attack);
      g.exponentialRampToValueAtTime(0.0001, at + attack + decay);
    }

    function crunch(power = 1) {
      if (muted || !ensure()) return;
      const t = ctx.currentTime;
      const src = ctx.createBufferSource();
      src.buffer = noise;
      const bp = ctx.createBiquadFilter();
      bp.type = 'bandpass'; bp.frequency.value = 1100 + Math.random() * 500; bp.Q.value = 0.9;
      const hp = ctx.createBiquadFilter();
      hp.type = 'highpass'; hp.frequency.value = 480;
      const g = ctx.createGain();
      env(g, 0.22 * power, 0.006, 0.16, t);
      src.connect(bp); bp.connect(hp); hp.connect(g); g.connect(ctx.destination);
      src.start(t); src.stop(t + 0.3);

      const o = ctx.createOscillator();
      o.type = 'sine'; o.frequency.setValueAtTime(140, t); o.frequency.exponentialRampToValueAtTime(64, t + 0.14);
      const og = ctx.createGain();
      env(og, 0.16 * power, 0.004, 0.14, t);
      o.connect(og); og.connect(ctx.destination);
      o.start(t); o.stop(t + 0.25);
    }

    function pop(freq = 620) {
      if (muted || !ensure()) return;
      const t = ctx.currentTime;
      const o = ctx.createOscillator();
      o.type = 'sine';
      o.frequency.setValueAtTime(freq, t);
      o.frequency.exponentialRampToValueAtTime(freq * 1.7, t + 0.09);
      const g = ctx.createGain();
      env(g, 0.09, 0.005, 0.12, t);
      o.connect(g); g.connect(ctx.destination);
      o.start(t); o.stop(t + 0.2);
    }

    function chime() {
      if (muted || !ensure()) return;
      const t = ctx.currentTime;
      [660, 880, 1320].forEach((f, i) => {
        const o = ctx.createOscillator();
        o.type = 'sine'; o.frequency.value = f;
        const g = ctx.createGain();
        g.gain.setValueAtTime(0.0001, t + i * 0.06);
        g.gain.exponentialRampToValueAtTime(0.06, t + i * 0.06 + 0.02);
        g.gain.exponentialRampToValueAtTime(0.0001, t + i * 0.06 + 0.8);
        o.connect(g); g.connect(ctx.destination);
        o.start(t + i * 0.06); o.stop(t + i * 0.06 + 0.9);
      });
    }

    return {
      get muted() { return muted; },
      get ready() { return ready; },
      toggle() {
        muted = !muted;
        try { localStorage.setItem('yoimachi-muted', muted ? '1' : '0'); } catch (_) {}
        ensure();
        if (!muted) pop(720);
        return muted;
      },
      prime() { ensure(); },
      crunch, pop, chime
    };
  })();

  const soundBtn = document.getElementById('soundBtn');
  function syncSound() {
    const m = audio.muted;
    soundBtn.setAttribute('aria-pressed', m ? 'true' : 'false');
    soundBtn.setAttribute('aria-label', m ? '已静音，点击开启声音' : '声音开启，点击静音');
    soundBtn.querySelector('.sound__label').textContent = m ? '静音' : '声音';
  }
  syncSound();
  soundBtn.addEventListener('click', () => {
    audio.prime();
    audio.toggle();
    syncSound();
  });

  /* --------------------------------------------------------------------------
     详情开合
     -------------------------------------------------------------------------- */
  const detailPlush = document.getElementById('detailPlush');
  const detailSushi = document.getElementById('detailSushi');
  let current = null, lastTrigger = null, lock = false;

  function openDetail(kind, trigger) {
    if (lock || current === kind) return;
    lock = true;
    lastTrigger = trigger || null;
    audio.prime();
    app.classList.add('has-interacted');
    app.classList.add('is-detail');
    if (window.Scene3D) Scene3D.focusShop(kind);
    if (kind === 'plush') {
      focus(470, 930, 1.78, 1050);
      setTimeout(() => {
        detailPlush.classList.add('is-open');
        detailPlush.setAttribute('aria-hidden', 'false');
        current = 'plush';
        lock = false;
        const back = detailPlush.querySelector('.back');
        if (back) back.focus({ preventScroll: true });
      }, 380);
    } else {
      focus(1100, 860, 1.78, 1050);
      setTimeout(() => {
        detailSushi.classList.add('is-open');
        detailSushi.setAttribute('aria-hidden', 'false');
        current = 'sushi';
        lock = false;
        const back = detailSushi.querySelector('.back');
        if (back) back.focus({ preventScroll: true });
      }, 380);
    }
  }

  function closeDetail() {
    if (!current) return;
    const el = current === 'plush' ? detailPlush : detailSushi;
    const was = current;
    el.classList.remove('is-open');
    el.setAttribute('aria-hidden', 'true');
    current = null;
    app.classList.remove('is-detail');
    if (window.Scene3D) Scene3D.resetView();
    focus(800, 820, 1, 1000);
    if (was === 'sushi' && sushiState.eaten >= 5) { /* 保留吃完的样子 */ }
    setTimeout(() => {
      if (lastTrigger && typeof lastTrigger.focus === 'function') lastTrigger.focus({ preventScroll: true });
    }, 700);
  }

  document.querySelectorAll('[data-open]').forEach((el) => {
    el.addEventListener('click', (e) => {
      const kind = el.getAttribute('data-open');
      openDetail(kind, el);
      e.preventDefault();
    });
    el.addEventListener('keydown', (e) => {
      if (e.key === 'Enter' || e.key === ' ') {
        e.preventDefault();
        openDetail(el.getAttribute('data-open'), el);
      }
    });
  });

  document.querySelectorAll('[data-close]').forEach((el) => {
    el.addEventListener('click', closeDetail);
  });

  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && current) closeDetail();
  });

  // 摊位悬停高亮
  const stallMap = {
    plush: document.getElementById('shop3dPlush'),
    sushi: document.getElementById('shop3dSushi')
  };
  document.querySelectorAll('.hotspot').forEach((hs) => {
    const kind = hs.getAttribute('data-open');
    hs.addEventListener('pointerenter', () => stallMap[kind]?.classList.add('is-hot'));
    hs.addEventListener('pointerleave', () => stallMap[kind]?.classList.remove('is-hot'));
  });

  /* --------------------------------------------------------------------------
     拼玩偶
     -------------------------------------------------------------------------- */
  const puzzleSvg = document.getElementById('puzzleSvg');
  const puzzleWrap = document.querySelector('.puzzle');
  const pieces = Array.from(document.querySelectorAll('.piece'));
  const plushCountEl = document.getElementById('plushCount');
  const plushBar = document.getElementById('plushBar');
  const plushDone = document.getElementById('plushDone');

  const PIECE_META = {
    head:  { cx: 320, cy: 240, tray: [812, 218], rot: -8 },
    body:  { cx: 320, cy: 390, tray: [792, 424], rot: 6 },
    armL:  { cx: 236, cy: 380, tray: [690, 540], rot: -32 },
    armR:  { cx: 404, cy: 380, tray: [916, 534], rot: 26 },
    legL:  { cx: 268, cy: 470, tray: [700, 622], rot: 11 },
    legR:  { cx: 372, cy: 470, tray: [900, 620], rot: -16 },
    bow:   { cx: 320, cy: 310, tray: [928, 356], rot: 24 }
  };

  let placed = 0;
  const pieceState = {};

  function trayTransform(name) {
    const m = PIECE_META[name];
    const dx = m.tray[0] - m.cx;
    const dy = m.tray[1] - m.cy;
    return { dx, dy, rot: m.rot };
  }

  function setPiece(name, dx, dy, rot) {
    const el = pieceState[name].el;
    el.style.transform = `translate(${dx}px,${dy}px) rotate(${rot}deg)`;
    pieceState[name].dx = dx;
    pieceState[name].dy = dy;
    pieceState[name].rot = rot;
  }

  pieces.forEach((el) => {
    const name = el.getAttribute('data-piece');
    const m = PIECE_META[name];
    el.style.transformOrigin = `${m.cx}px ${m.cy}px`;
    if (!el.hasAttribute('tabindex')) el.setAttribute('tabindex', '0');
    pieceState[name] = { el, dx: 0, dy: 0, rot: 0, done: false };
    const t = trayTransform(name);
    setPiece(name, t.dx, t.dy, t.rot);
    bindKeys(name, el);
  });

  /* 拖动统一挂在 SVG 根上：
     1) 不在 pointerdown 时把零件 appendChild 到末尾（会丢 pointer capture，小零件一拖就断）
     2) capture 设在 <svg> 上，指针移出零件/移出卡片也继续收到事件
     3) 变换用 rAF 合并，一帧只写一次 transform
     4) 拖动时关掉每个零件的 feDropShadow，避免每帧重算滤镜 */
  const drag = { active: false, name: null, pid: null, start: null, base: null, raf: 0, next: null, inv: null };

  function flushDrag() {
    drag.raf = 0;
    if (!drag.next || !drag.name) return;
    const st = pieceState[drag.name];
    if (!st) return;
    setPiece(drag.name, drag.next.dx, drag.next.dy, drag.base.rot);
    drag.next = null;
  }

  puzzleSvg.addEventListener('pointerdown', (e) => {
    if (e.pointerType === 'mouse' && e.button !== 0) return;
    const el = e.target && e.target.closest ? e.target.closest('.piece') : null;
    if (!el) return;
    const name = el.getAttribute('data-piece');
    const st = pieceState[name];
    if (!st || st.done) return;
    e.preventDefault();
    drag.active = true;
    drag.name = name;
    drag.pid = e.pointerId;
    drag.inv = puzzleSvg.getScreenCTM().inverse();
    drag.start = new DOMPoint(e.clientX, e.clientY).matrixTransform(drag.inv);
    drag.base = { dx: st.dx, dy: st.dy, rot: st.rot };
    drag.next = null;
    el.classList.add('is-drag');
    puzzleSvg.classList.add('is-dragging');
    try { puzzleSvg.setPointerCapture(e.pointerId); } catch (_) {}
    audio.prime();
  });

  puzzleSvg.addEventListener('pointermove', (e) => {
    if (!drag.active || e.pointerId !== drag.pid) return;
    const p = new DOMPoint(e.clientX, e.clientY).matrixTransform(drag.inv);
    drag.next = {
      dx: drag.base.dx + (p.x - drag.start.x),
      dy: drag.base.dy + (p.y - drag.start.y)
    };
    if (!drag.raf) drag.raf = requestAnimationFrame(flushDrag);
  });

  function endDrag(e) {
    if (!drag.active || (e && e.pointerId !== drag.pid)) return;
    if (drag.raf) { cancelAnimationFrame(drag.raf); drag.raf = 0; }
    flushDrag();
    const name = drag.name;
    const pid = drag.pid;
    const el = pieceState[name].el;
    drag.active = false;
    el.classList.remove('is-drag');
    puzzleSvg.classList.remove('is-dragging');
    try { if (puzzleSvg.hasPointerCapture(pid)) puzzleSvg.releasePointerCapture(pid); } catch (_) {}
    const st = pieceState[name];
    if (Math.hypot(st.dx, st.dy) < 64) {
      placePiece(name);
    } else {
      const t = trayTransform(name);
      el.style.transition = 'transform .45s cubic-bezier(.22,.9,.3,1.12)';
      setPiece(name, t.dx, t.dy, t.rot);
      setTimeout(() => { el.style.transition = ''; }, 480);
      audio.pop(380);
    }
    drag.name = null;
    drag.pid = null;
    drag.start = null;
    drag.base = null;
    drag.inv = null;
    drag.next = null;
  }
  puzzleSvg.addEventListener('pointerup', endDrag);
  puzzleSvg.addEventListener('pointercancel', endDrag);

  function bindKeys(name, el) {
    el.addEventListener('keydown', (e) => {
      if ((e.key === 'Enter' || e.key === ' ') && !pieceState[name].done) {
        e.preventDefault();
        placePiece(name);
      }
    });

    el.addEventListener('dblclick', (e) => {
      e.preventDefault();
      if (!pieceState[name].done) placePiece(name);
    });
  }

  function placePiece(name) {
    const st = pieceState[name];
    if (st.done) return;
    st.done = true;
    st.el.classList.remove('is-drag');
    st.el.classList.add('is-placed');
    st.el.style.transition = 'transform .4s cubic-bezier(.22,.9,.3,1.12)';
    setPiece(name, 0, 0, 0);
    setTimeout(() => { st.el.style.transition = ''; }, 430);
    placed++;
    plushCountEl.textContent = placed;
    plushBar.style.width = `${(placed / 7) * 100}%`;
    audio.pop(520 + placed * 46);
    sparkleAt(st.el);
    if (placed >= 7) setTimeout(finishPuzzle, 480);
  }

  function sparkleAt(el) {
    try {
      const box = el.getBBox();
      const svgBox = puzzleSvg.getBoundingClientRect();
      const ctm = puzzleSvg.getScreenCTM();
      const pt = puzzleSvg.createSVGPoint();
      pt.x = box.x + box.width / 2;
      pt.y = box.y + box.height / 2;
      const screen = pt.matrixTransform(ctm);
      for (let i = 0; i < 5; i++) {
        const s = document.createElement('span');
        s.className = 'confetti';
        s.style.left = (screen.x - svgBox.left) + 'px';
        s.style.top = (screen.y - svgBox.top) + 'px';
        s.style.background = ['#e8c07c', '#cf4530', '#9ad3c2', '#f6c1a0'][i % 4];
        s.style.setProperty('--cx', (Math.random() * 70 - 35) + 'px');
        s.style.setProperty('--cy', (Math.random() * -60 - 20) + 'px');
        s.style.setProperty('--cr', (Math.random() * 260 - 130) + 'deg');
        s.style.animationDuration = '.9s';
        puzzleWrap.appendChild(s);
        setTimeout(() => s.remove(), 1000);
      }
    } catch (_) {}
  }

  function finishPuzzle() {
    puzzleWrap.classList.add('is-done');
    plushDone.hidden = false;
    audio.chime();
    confettiBurst(puzzleWrap);
  }

  function confettiBurst(host) {
    const colors = ['#cf4530', '#e8c07c', '#9ad3c2', '#f6c1a0', '#f2e6d2'];
    for (let i = 0; i < 26; i++) {
      const c = document.createElement('span');
      c.className = 'confetti';
      c.style.left = '50%';
      c.style.top = '46%';
      c.style.background = colors[i % colors.length];
      c.style.setProperty('--cx', (Math.random() * 460 - 230) + 'px');
      c.style.setProperty('--cy', (Math.random() * -260 - 60) + 'px');
      c.style.setProperty('--cr', (Math.random() * 620 - 310) + 'deg');
      c.style.animationDelay = (Math.random() * 0.25) + 's';
      host.appendChild(c);
      setTimeout(() => c.remove(), 2200);
    }
  }

  function resetPuzzle() {
    placed = 0;
    plushCountEl.textContent = '0';
    plushBar.style.width = '0%';
    puzzleWrap.classList.remove('is-done');
    plushDone.hidden = true;
    pieces.forEach((el) => {
      const name = el.getAttribute('data-piece');
      const st = pieceState[name];
      st.done = false;
      el.classList.remove('is-placed');
      const t = trayTransform(name);
      el.style.transition = 'transform .55s cubic-bezier(.22,.9,.3,1.12)';
      setPiece(name, t.dx, t.dy, t.rot);
      setTimeout(() => { el.style.transition = ''; }, 580);
    });
    audio.pop(420);
  }

  document.getElementById('plushReset').addEventListener('click', resetPuzzle);
  document.getElementById('plushAgain').addEventListener('click', resetPuzzle);

  /* --------------------------------------------------------------------------
     寿司：一口一口吃掉
     -------------------------------------------------------------------------- */
  const sushiSvg = document.getElementById('sushiSvg');
  const sushiStage = document.getElementById('sushiStage');
  const sushiGroup = document.getElementById('sushiGroup');
  const plateGroup = document.getElementById('plateGroup');
  const biteShapes = document.getElementById('biteShapes');
  const bitesClipInner = document.getElementById('bitesClipInner');
  const biteRims = document.getElementById('biteRims');
  const silShape = document.getElementById('silShape');
  const crumbsG = document.getElementById('crumbs');
  const sauceG = document.getElementById('sauce');
  const soyG = document.getElementById('soyDrops');
  const biteHint = document.getElementById('biteHint');
  const biteHintText = biteHint.querySelector('span');
  const dotsWrap = document.getElementById('bitesDots');
  const sushiLine = document.getElementById('sushiLine');
  const sushiDone = document.getElementById('sushiDone');
  const sushiAgain = document.getElementById('sushiAgain');
  const sushiAgain2 = document.getElementById('sushiAgain2');

  const NS = 'http://www.w3.org/2000/svg';
  const sushiState = { eaten: 0, busy: false, total: 5 };

  const BITES = [
    { circles: [[610, 348, 44], [644, 378, 34], [574, 324, 32]], drops: [[648, 470, 8], [602, 486, 5]] },
    { circles: [[650, 410, 40], [628, 438, 30], [664, 382, 28]], drops: [[600, 492, 6], [670, 460, 5]] },
    { circles: [[506, 306, 42], [548, 298, 30], [470, 318, 30]], drops: [[520, 480, 8], [560, 492, 5]] },
    { circles: [[300, 344, 40], [258, 376, 30], [340, 324, 28]], drops: [[286, 474, 8], [330, 488, 5]] },
    { circles: [[450, 420, 62], [386, 430, 46], [520, 414, 44], [306, 418, 40], [596, 408, 36], [450, 360, 50]], drops: [[420, 488, 10], [500, 494, 6], [350, 496, 5], [588, 472, 4]] }
  ];

  const LINES = [
    '还完整的一贯，先从哪下口？',
    '第一口，先咬最肥的那一边。',
    '米饭还是温的。',
    '鲑鱼的油脂，在嘴里化开了。',
    '只剩一小口了。',
    '吃完了，好满足。'
  ];

  // 用寿司外轮廓建立断面遮罩
  (function buildSilhouette() {
    ['riceBody', 'salmonBody'].forEach((id) => {
      const src = document.getElementById(id);
      if (!src) return;
      const p = document.createElementNS(NS, 'path');
      p.setAttribute('d', src.getAttribute('d'));
      p.setAttribute('fill', '#fff');
      silShape.appendChild(p);
    });
  })();

  // 咬口计数点
  for (let i = 0; i < 5; i++) {
    const d = document.createElement('i');
    dotsWrap.appendChild(d);
  }
  const dots = Array.from(dotsWrap.children);

  function bite() {
    if (sushiState.busy || sushiState.eaten >= 5) return;
    sushiState.busy = true;
    const idx = sushiState.eaten;
    const data = BITES[idx];

    audio.crunch(idx === 0 ? 1.15 : 1);

    data.circles.forEach(([cx, cy, r], i) => {
      [[biteShapes, '#000'], [bitesClipInner, '#fff']].forEach(([host, fill]) => {
        const c = document.createElementNS(NS, 'circle');
        c.setAttribute('cx', cx);
        c.setAttribute('cy', cy);
        c.setAttribute('r', r);
        c.setAttribute('fill', fill);
        c.style.transformBox = 'fill-box';
        c.style.transformOrigin = 'center';
        c.style.animation = `chompIn .34s cubic-bezier(.22,.9,.3,1.2) ${i * 40}ms both`;
        host.appendChild(c);
      });
      const rim = document.createElementNS(NS, 'circle');
      rim.setAttribute('cx', cx);
      rim.setAttribute('cy', cy);
      rim.setAttribute('r', Math.max(2, r - 1.5));
      biteRims.appendChild(rim);
    });

    // 酱汁
    data.drops.forEach(([x, y, r], i) => {
      const c = document.createElementNS(NS, 'ellipse');
      c.setAttribute('cx', x); c.setAttribute('cy', y);
      c.setAttribute('rx', r); c.setAttribute('ry', r * 0.52);
      c.setAttribute('fill', '#8a3a1e');
      c.setAttribute('opacity', '.85');
      c.style.transformBox = 'fill-box'; c.style.transformOrigin = 'center';
      c.style.animation = `dropIn .4s cubic-bezier(.22,.9,.3,1.2) ${120 + i * 50}ms both`;
      sauceG.appendChild(c);
      const s = document.createElementNS(NS, 'circle');
      s.setAttribute('cx', x - 2); s.setAttribute('cy', y - 2); s.setAttribute('r', Math.max(1.6, r * 0.22));
      s.setAttribute('fill', '#b85a2e'); s.setAttribute('opacity', '.7');
      soyG.appendChild(s);
    });

    const [bx, by] = data.circles[0];
    const screen = toScreen(bx, by);
    const rect = sushiStage.getBoundingClientRect();
    const pop = document.createElement('span');
    pop.className = 'bite-pop';
    pop.textContent = ['咔', '咔', '嚓', '咔', '咕'][idx] || '咔';
    pop.style.left = (screen.x - rect.left) + 'px';
    pop.style.top = (screen.y - rect.top) + 'px';
    sushiStage.appendChild(pop);
    setTimeout(() => pop.remove(), 760);

    sushiGroup.classList.remove('chomp');
    plateGroup.classList.remove('jiggle');
    void sushiGroup.getBoundingClientRect();
    sushiGroup.classList.add('chomp');
    plateGroup.classList.add('jiggle');
    setTimeout(() => { sushiGroup.classList.remove('chomp'); plateGroup.classList.remove('jiggle'); }, 520);

    spawnCrumbs(data.circles);

    sushiState.eaten++;
    dots[idx].classList.add('is-eaten');
    sushiLine.textContent = LINES[idx + 1];
    sushiLine.style.opacity = '0';
    setTimeout(() => { sushiLine.style.opacity = '1'; }, 60);
    biteHintText.textContent = idx === 4 ? '最后一口' : ['第一口 · 再来', '第二口 · 好香', '第三口 · 停不下', '第四口 · 只剩一点'][idx] || '点一下 · 咬一口';
    if (idx < 4) audio.pop(700 + idx * 30);

    setTimeout(() => {
      sushiState.busy = false;
      if (sushiState.eaten >= 5) finishSushi();
    }, 460);
  }

  function finishSushi() {
    setTimeout(() => {
      sushiGroup.style.transition = 'opacity .45s ease';
      sushiGroup.style.opacity = '0';
      sushiDone.hidden = false;
      sushiLine.textContent = 'ごちそうさま。';
      audio.chime();
      confettiBurst(sushiDone);
    }, 220);
  }

  function toScreen(x, y) {
    const pt = sushiSvg.createSVGPoint();
    pt.x = x; pt.y = y;
    return pt.matrixTransform(sushiSvg.getScreenCTM());
  }

  let crumbParticles = [];
  let crumbRaf = null;

  function spawnCrumbs(circles) {
    if (document.documentElement.classList.contains('still')) return;
    const colors = ['#fdf8ec', '#ffb08c', '#e8654b', '#f5e9d6'];
    circles.forEach(([cx, cy, r]) => {
      const n = Math.round(r / 12);
      for (let i = 0; i < n; i++) {
        const c = document.createElementNS(NS, 'circle');
        const size = 1 + Math.random() * 2.8;
        c.setAttribute('r', size);
        c.setAttribute('cx', cx + (Math.random() - 0.5) * r);
        c.setAttribute('cy', cy + (Math.random() - 0.5) * r * 0.7);
        c.setAttribute('fill', colors[Math.floor(Math.random() * colors.length)]);
        c.setAttribute('opacity', '.95');
        crumbsG.appendChild(c);
        crumbParticles.push({
          el: c,
          x: +c.getAttribute('cx'),
          y: +c.getAttribute('cy'),
          vx: (Math.random() - 0.5) * 4.4,
          vy: -Math.random() * 4.2 - 1.2,
          life: 1
        });
      }
    });
    if (!crumbRaf) crumbRaf = requestAnimationFrame(tickCrumbs);
  }

  let lastT = 0;
  function tickCrumbs(t) {
    const dt = Math.min(28, t - (lastT || t)) / 16.7;
    lastT = t;
    for (let i = crumbParticles.length - 1; i >= 0; i--) {
      const p = crumbParticles[i];
      p.vy += 0.26 * dt;
      p.x += p.vx * dt;
      p.y += p.vy * dt;
      p.life -= 0.016 * dt;
      if (p.life <= 0) {
        p.el.remove();
        crumbParticles.splice(i, 1);
      } else {
        p.el.setAttribute('cx', p.x);
        p.el.setAttribute('cy', p.y);
        p.el.setAttribute('opacity', Math.max(0, p.life));
      }
    }
    if (crumbParticles.length) {
      crumbRaf = requestAnimationFrame(tickCrumbs);
    } else {
      crumbRaf = null; lastT = 0;
    }
  }

  function resetSushi() {
    sushiState.eaten = 0;
    sushiState.busy = false;
    biteShapes.innerHTML = '';
    bitesClipInner.innerHTML = '';
    biteRims.innerHTML = '';
    sauceG.innerHTML = '';
    soyG.innerHTML = '';
    crumbsG.innerHTML = '';
    crumbParticles = [];
    dots.forEach((d) => d.classList.remove('is-eaten'));
    sushiDone.hidden = true;
    sushiGroup.style.opacity = '1';
    sushiGroup.style.transition = 'none';
    sushiGroup.style.transform = 'scale(.9)';
    sushiGroup.style.transformOrigin = '450px 400px';
    sushiGroup.style.transformBox = 'view-box';
    setTimeout(() => {
      sushiGroup.style.transition = 'transform .5s cubic-bezier(.22,.9,.3,1.2)';
      sushiGroup.style.transform = 'scale(1)';
    }, 30);
    sushiLine.textContent = LINES[0];
    biteHintText.textContent = '点一下 · 咬一口';
    audio.pop(480);
  }

  sushiStage.addEventListener('click', (e) => {
    if (e.target.closest('.link-btn,.btn')) return;
    sushiStage.blur();
    bite();
  });
  sushiAgain.addEventListener('click', resetSushi);
  sushiAgain2.addEventListener('click', resetSushi);

  // 咬口圆圈的入场动画（全局 keyframes 注入）
  const style = document.createElement('style');
  style.textContent = `
    @keyframes chompIn{from{transform:scale(0)}to{transform:scale(1)}}
    @keyframes dropIn{from{transform:scale(0);opacity:0}to{transform:scale(1);opacity:.85}}
  `;
  document.head.appendChild(style);

  /* --------------------------------------------------------------------------
     飘落花瓣 / 萤火
     -------------------------------------------------------------------------- */
  const fx = document.getElementById('fx');
  function seedAmbient() {
    if (reduceMotion) return;
    for (let i = 0; i < 14; i++) {
      const p = document.createElement('i');
      p.className = 'petal';
      p.style.left = (Math.random() * 100) + 'vw';
      p.style.width = (5 + Math.random() * 7) + 'px';
      p.style.height = (7 + Math.random() * 9) + 'px';
      p.style.animationDuration = (13 + Math.random() * 16) + 's';
      p.style.animationDelay = (-Math.random() * 26) + 's';
      p.style.setProperty('--dx', (Math.random() * 160 - 60) + 'px');
      p.style.opacity = '0';
      fx.appendChild(p);
    }
    for (let i = 0; i < 16; i++) {
      const f = document.createElement('i');
      f.className = 'firefly';
      f.style.left = (Math.random() * 100) + 'vw';
      f.style.top = (28 + Math.random() * 46) + 'vh';
      f.style.animationDuration = (7 + Math.random() * 8) + 's';
      f.style.animationDelay = (-Math.random() * 10) + 's';
      f.style.width = f.style.height = (2.5 + Math.random() * 2.5) + 'px';
      fx.appendChild(f);
    }
  }
  seedAmbient();

  /* 行人：沿南北向街道来回走，北向/南向两组，全部持续移动 */
  const pedLayer = document.getElementById('pedestrians');
  const PED_STYLES = [
    ['#5c7f86', '#e8c07c'], ['#b85a70', '#f0c05a'], ['#3f5674', '#c9a06a'],
    ['#6b4a6e', '#e8c07c'], ['#4d5f4a', '#a8452f'], ['#7a4a6a', '#e8c07c'],
    ['#4b6a7a', '#d9a23f'], ['#8a5a4a', '#c9a06a'], ['#c25a6a', '#f0c05a'],
    ['#5a3a52', '#b98a4a'], ['#3a4a5a', '#c9a06a'], ['#7c6a8a', '#b98d55']
  ];

  function pedEdges(y) {
    let l = 620, r = 980;
    if (y > 1000) r = 980 + Math.min(1, (y - 1000) / 120) * 320;
    if (y > 1120) {
      l = 620 - Math.min(1, (y - 1120) / 480) * 440;
      r = 1300 + Math.min(1, (y - 1120) / 480) * 120;
    }
    return [l, r];
  }

  const peds = [];
  if (pedLayer) {
    for (let i = 0; i < 18; i++) {
      const style = PED_STYLES[i % PED_STYLES.length];
      const front = i % 6 === 5 ? 'granny' : (i % 2 ? 'girl' : 'boy');
      const el = document.createElementNS(NS, 'g');
      el.setAttribute('class', 'ped');
      const shadow = document.createElementNS(NS, 'ellipse');
      shadow.setAttribute('cx', 0); shadow.setAttribute('cy', 4);
      shadow.setAttribute('rx', 22); shadow.setAttribute('ry', 5);
      shadow.setAttribute('fill', '#000'); shadow.setAttribute('opacity', '.22');
      el.appendChild(shadow);
      const use = document.createElementNS(NS, 'use');
      use.setAttribute('x', '-60'); use.setAttribute('y', '-300');
      use.setAttribute('width', '120'); use.setAttribute('height', '300');
      use.style.setProperty('--yukata', style[0]);
      use.style.setProperty('--obi', style[1]);
      el.appendChild(use);
      pedLayer.appendChild(el);
      const p = {
        el, use, front, back: front === 'boy' ? 'boyBack' : 'girlBack',
        y: 780 + ((i + 0.5) / 18) * 680 + (Math.random() * 2 - 1) * 10,
        lane: (Math.random() * 2 - 1) * 0.85,
        dir: i % 2 ? 1 : -1,
        speed: 26 + Math.random() * 30,
        phase: i * 1.7,
        cur: front
      };
      if (front === 'granny') use.style.setProperty('--hair', '#cfc6c0');
      use.setAttribute('href', '#' + front);
      peds.push(p);
    }

    let lastPedT = performance.now();
    let sortT = 0;
    const tickPeds = (t) => {
      const dt = Math.min(0.05, Math.max(0, (t - lastPedT) / 1000));
      lastPedT = t;
      if (!app.classList.contains('is-detail')) {
        for (const p of peds) {
          p.y += p.dir * p.speed * dt;
          if (p.y > 1480) { p.y = 1480; p.dir = -1; }
          if (p.y < 765) { p.y = 765; p.dir = 1; }
          const [l, r] = pedEdges(p.y);
          const x = l + (p.lane + 1) / 2 * (r - l);
          const sc = 0.18 + (p.y - 760) / 720 * 0.62;
          const bob = Math.sin(t / 160 + p.phase) * 2;
          p.el.setAttribute('transform', `translate(${x} ${p.y + bob}) scale(${sc})`);
          const want = p.dir > 0 ? p.front : p.back;
          if (p.cur !== want) {
            p.use.setAttribute('href', '#' + want);
            p.cur = want;
          }
        }
        if (t - sortT > 400) {
          sortT = t;
          peds.slice().sort((a, b) => a.y - b.y).forEach((p) => pedLayer.appendChild(p.el));
        }
      }
      requestAnimationFrame(tickPeds);
    };
    requestAnimationFrame(tickPeds);
  }
  /* --------------------------------------------------------------------------
     首次交互提示
     -------------------------------------------------------------------------- */
  ['pointerdown', 'wheel'].forEach((ev) => {
    window.addEventListener(ev, () => app.classList.add('has-interacted'), { once: true, passive: true });
  });

  /* 用场景里的店铺原画克隆到 3D 盒子的正面（矢量、保留原动画） */
  function buildShopFronts() {
    const defs = [
      { key: 'plush', src: 'stallPlush', vb: '262 600 476 600' },
      { key: 'sushi', src: 'stallSushi', vb: '880 600 476 600' }
    ];
    for (const d of defs) {
      const face = document.querySelector(`[data-front="${d.key}"]`);
      const src = document.getElementById(d.src);
      if (!face || !src) continue;
      const clone = src.cloneNode(true);
      clone.removeAttribute('id');
      clone.querySelectorAll('.shop-depth,.shop-eave,.chalkboard').forEach((n) => n.remove());
      clone.querySelectorAll('[id]').forEach((n) => n.removeAttribute('id'));
      const svg = document.createElementNS(NS, 'svg');
      svg.setAttribute('viewBox', d.vb);
      svg.setAttribute('preserveAspectRatio', 'none');
      svg.appendChild(clone);
      face.appendChild(svg);
    }
  }
  buildShopFronts();
  /* --------------------------------------------------------------------------
     预览用：?open=plush|sushi 直接打开详情（也方便截图核对）
     -------------------------------------------------------------------------- */
  const query = new URLSearchParams(location.search);
  const qOpen = query.get('open');
  const still = query.get('still') === '1';
  if (still) document.documentElement.classList.add('still');

  if (still && (qOpen === 'plush' || qOpen === 'sushi')) {
    app.classList.add('is-ready');
    app.classList.add('has-interacted');
    app.classList.add('is-detail');
    const detail = qOpen === 'plush' ? detailPlush : detailSushi;
    focus(qOpen === 'plush' ? 470 : 1100, qOpen === 'plush' ? 930 : 860, 1.78, 0);
    detail.classList.add('is-open');
    detail.setAttribute('aria-hidden', 'false');
    current = qOpen;
    if (qOpen === 'plush' && query.get('solve') === '1') {
      Object.keys(pieceState).forEach((name) => placePiece(name));
      finishPuzzle();
    }
    if (qOpen === 'sushi') {
      const n = Math.min(4, parseInt(query.get('bites') || '0', 10));
      for (let i = 0; i < n; i++) { bite(); sushiState.busy = false; }
    }
  } else if (qOpen === 'plush' || qOpen === 'sushi') {
    app.classList.add('is-ready');
    app.classList.add('has-interacted');
    if (qOpen === 'plush') {
      setTimeout(() => {
        openDetail('plush', null);
        if (query.get('solve') === '1') {
          setTimeout(() => {
            Object.keys(pieceState).forEach((name, i) => setTimeout(() => placePiece(name), i * 130));
          }, 900);
        }
      }, 260);
    } else {
      setTimeout(() => {
        openDetail('sushi', null);
        const n = Math.min(5, parseInt(query.get('bites') || '0', 10));
        for (let i = 0; i < n; i++) setTimeout(bite, 1300 + i * 650);
      }, 260);
    }
  }

  window.__openDetail = openDetail;
  window.__closeDetail = closeDetail;
})();
