/* ============================================================================
   宵町横丁 · 真 3D 街景（原生 WebGL，无外部依赖）
   店铺是真实几何体：营业面朝街心、南侧端墙朝镜头、柜台/棚布/招牌有体积；
   行人是在同一深度缓冲里的广告牌 Sprite，会被店铺真实遮挡，不会穿模。
   ========================================================================== */
(function () {
  'use strict';

  const canvas = document.getElementById('glscene');
  if (!canvas) return;
  const viewport = document.getElementById('viewport');
  const app = document.getElementById('app');
  const gl = canvas.getContext('webgl', { antialias: true, alpha: false, premultipliedAlpha: false });
  if (!gl) { canvas.style.display = 'none'; return; }

  /* ---------------------------------- 数学 ---------------------------------- */
  const v3 = {
    sub: (a, b) => [a[0] - b[0], a[1] - b[1], a[2] - b[2]],
    add: (a, b) => [a[0] + b[0], a[1] + b[1], a[2] + b[2]],
    mul: (a, s) => [a[0] * s, a[1] * s, a[2] * s],
    dot: (a, b) => a[0] * b[0] + a[1] * b[1] + a[2] * b[2],
    cross: (a, b) => [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]],
    len: (a) => Math.hypot(a[0], a[1], a[2]),
    norm: (a) => { const l = Math.hypot(a[0], a[1], a[2]) || 1; return [a[0] / l, a[1] / l, a[2] / l]; }
  };
  function mul4(a, b) {
    const o = new Float32Array(16);
    for (let c = 0; c < 4; c++) for (let r = 0; r < 4; r++) {
      o[c * 4 + r] = a[r] * b[c * 4] + a[4 + r] * b[c * 4 + 1] + a[8 + r] * b[c * 4 + 2] + a[12 + r] * b[c * 4 + 3];
    }
    return o;
  }
  function perspective(fovy, aspect, near, far) {
    const f = 1 / Math.tan(fovy / 2), nf = 1 / (near - far);
    return new Float32Array([
      f / aspect, 0, 0, 0,
      0, f, 0, 0,
      0, 0, (far + near) * nf, -1,
      0, 0, 2 * far * near * nf, 0
    ]);
  }
  function lookAt(eye, target, up) {
    const z = v3.norm(v3.sub(eye, target));
    const x = v3.norm(v3.cross(up, z));
    const y = v3.cross(z, x);
    return new Float32Array([
      x[0], y[0], z[0], 0,
      x[1], y[1], z[1], 0,
      x[2], y[2], z[2], 0,
      -v3.dot(x, eye), -v3.dot(y, eye), -v3.dot(z, eye), 1
    ]);
  }
  function projectPoint(vp, p) {
    const x = p[0], y = p[1], z = p[2];
    const cx = vp[0] * x + vp[4] * y + vp[8] * z + vp[12];
    const cy = vp[1] * x + vp[5] * y + vp[9] * z + vp[13];
    const cw = vp[3] * x + vp[7] * y + vp[11] * z + vp[15];
    if (cw <= 0.001) return null;
    return [cx / cw, cy / cw];
  }

  /* --------------------------------- Shader --------------------------------- */
  const VS = `
    attribute vec3 aPos;
    attribute vec2 aUV;
    uniform mat4 uModel, uView, uProj;
    uniform vec2 uUVScale;
    varying vec2 vUV;
    varying vec3 vWorld;
    void main() {
      vec4 world = uModel * vec4(aPos, 1.0);
      vWorld = world.xyz;
      vUV = aUV * uUVScale;
      gl_Position = uProj * uView * world;
    }`;
  const FS = `
    precision mediump float;
    uniform sampler2D uTex;
    uniform vec4 uColor;
    uniform vec3 uFogColor, uCamPos;
    uniform float uFogNear, uFogFar;
    varying vec2 vUV;
    varying vec3 vWorld;
    void main() {
      vec4 t = texture2D(uTex, vUV);
      vec4 c = t * uColor;
      if (c.a < 0.03) discard;
      float dist = length(vWorld - uCamPos);
      float fog = clamp((dist - uFogNear) / (uFogFar - uFogNear), 0.0, 1.0);
      c.rgb = mix(c.rgb, uFogColor, fog * 0.88);
      gl_FragColor = c;
    }`;
  function compile(type, src) {
    const s = gl.createShader(type); gl.shaderSource(s, src); gl.compileShader(s);
    if (!gl.getShaderParameter(s, gl.COMPILE_STATUS)) { console.error(gl.getShaderInfoLog(s)); return null; }
    return s;
  }
  const prog = gl.createProgram();
  const vs = compile(gl.VERTEX_SHADER, VS), fs = compile(gl.FRAGMENT_SHADER, FS);
  if (!vs || !fs) return;
  gl.attachShader(prog, vs); gl.attachShader(prog, fs); gl.linkProgram(prog);
  if (!gl.getProgramParameter(prog, gl.LINK_STATUS)) { console.error(gl.getProgramInfoLog(prog)); return; }
  gl.useProgram(prog);
  const A = { pos: gl.getAttribLocation(prog, 'aPos'), uv: gl.getAttribLocation(prog, 'aUV') };
  const U = {};
  ['uModel', 'uView', 'uProj', 'uUVScale', 'uTex', 'uColor', 'uFogColor', 'uCamPos', 'uFogNear', 'uFogFar'].forEach((n) => { U[n] = gl.getUniformLocation(prog, n); });

  // 单位四边形
  const quadBuf = gl.createBuffer();
  gl.bindBuffer(gl.ARRAY_BUFFER, quadBuf);
  gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([
    -0.5, -0.5, 0, 0, 1,
    0.5, -0.5, 0, 1, 1,
    0.5, 0.5, 0, 1, 0,
    -0.5, 0.5, 0, 0, 0
  ]), gl.STATIC_DRAW);
  const idxBuf = gl.createBuffer();
  gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, idxBuf);
  gl.bufferData(gl.ELEMENT_ARRAY_BUFFER, new Uint16Array([0, 1, 2, 0, 2, 3]), gl.STATIC_DRAW);

  /* --------------------------------- 纹理 ---------------------------------- */
  const sceneSvg = document.getElementById('scene');
  const defsMarkup = sceneSvg && sceneSvg.querySelector('defs') ? sceneSvg.querySelector('defs').outerHTML : '';
  const FONT = '"Songti SC","Noto Serif SC","Hiragino Mincho ProN",serif';
  function svgURI(inner, vb, w, h) {
    const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="${w}" height="${h}" viewBox="${vb}">` +
      `<style>text{font-family:${FONT};}</style>${defsMarkup}${inner}</svg>`;
    return 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(svg);
  }
  function makeTex() {
    const t = gl.createTexture();
    gl.bindTexture(gl.TEXTURE_2D, t);
    gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, 1, 1, 0, gl.RGBA, gl.UNSIGNED_BYTE, new Uint8Array([255, 255, 255, 255]));
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
    return t;
  }
  function uploadSource(t, src, wrapRepeat) {
    gl.bindTexture(gl.TEXTURE_2D, t);
    gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL, false);
    gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, src);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, wrapRepeat ? gl.REPEAT : gl.CLAMP_TO_EDGE);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, wrapRepeat ? gl.REPEAT : gl.CLAMP_TO_EDGE);
  }
  function texFromImage(uri, repeat) {
    const t = makeTex();
    const img = new Image();
    img.onload = () => uploadSource(t, img, !!repeat);
    img.src = uri;
    return t;
  }
  function texFromCanvas(cv, repeat) {
    const t = makeTex();
    uploadSource(t, cv, !!repeat);
    return t;
  }
  const white = makeTex();

  // —— 店铺原画纹理（从隐藏的 SVG 店铺克隆，去掉旧伪 3D 层）
  function shopArt(kind) {
    const src = document.getElementById(kind === 'plush' ? 'stallPlush' : 'stallSushi');
    if (!src) return null;
    const clone = src.cloneNode(true);
    clone.removeAttribute('id');
    clone.querySelectorAll('.shop-depth,.shop-eave,.chalkboard').forEach((n) => n.remove());
    clone.querySelectorAll('[id]').forEach((n) => n.removeAttribute('id'));
    const vb = kind === 'plush' ? '262 600 476 600' : '880 600 476 600';
    return svgURI(clone.outerHTML, vb, 520, 640);
  }
  // —— 行人纹理
  const PED_COLORS = [
    ['#5c7f86', '#e8c07c'], ['#b85a70', '#f0c05a'], ['#3f5674', '#c9a06a'],
    ['#6b4a6e', '#e8c07c'], ['#4d5f4a', '#a8452f'], ['#7a4a6a', '#e8c07c'],
    ['#4b6a7a', '#d9a23f'], ['#8a5a4a', '#c9a06a'], ['#c25a6a', '#f0c05a'],
    ['#5a3a52', '#b98a4a'], ['#3a4a5a', '#c9a06a'], ['#7c6a8a', '#b98d55']
  ];
  function pedArt(sym, col, hair) {
    const use = `<g style="--yukata:${col[0]};--obi:${col[1]};--hair:${hair || '#241a1a'}"><use href="#${sym}" x="0" y="0" width="120" height="300"/></g>`;
    return svgURI(use, '0 0 120 300', 240, 600);
  }
  function backdropArt() {
    if (!sceneSvg) return null;
    const clone = sceneSvg.cloneNode(true);
    clone.querySelectorAll('#stallPlush,#stallSushi,#pedestrians,.vignette,.petals').forEach((n) => n.remove());
    clone.setAttribute('xmlns', 'http://www.w3.org/2000/svg');
    clone.setAttribute('xmlns:xlink', 'http://www.w3.org/1999/xlink');
    clone.setAttribute('viewBox', '0 0 1600 900');
    clone.setAttribute('width', '1600');
    clone.setAttribute('height', '900');
    clone.setAttribute('class', '');
    return 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(clone.outerHTML);
  }

  // —— Canvas 纹理
  function groundCanvas() {
    const cv = document.createElement('canvas'); cv.width = 1024; cv.height = 1024;
    const x = cv.getContext('2d');
    x.fillStyle = '#241b18'; x.fillRect(0, 0, 1024, 1024);
    const g = x.createRadialGradient(512, 640, 60, 512, 640, 700);
    g.addColorStop(0, 'rgba(120,82,58,.38)'); g.addColorStop(0.55, 'rgba(60,38,30,.12)'); g.addColorStop(1, 'rgba(0,0,0,0)');
    x.fillStyle = g; x.fillRect(0, 0, 1024, 1024);
    for (let row = 0; row < 18; row++) {
      const y = row * 58 + 4;
      const off = (row % 2) * 64;
      for (let col = -1; col < 10; col++) {
        const w = 96 + ((row * 7 + col * 13) % 40);
        const h = 50;
        const px = col * 118 + off + 4;
        x.fillStyle = `rgba(${38 + (row * 5) % 18},${29 + (col * 3) % 12},${24 + (row * 2) % 10},.85)`;
        x.fillRect(px, y, w, h);
        x.strokeStyle = 'rgba(12,8,7,.75)'; x.lineWidth = 3; x.strokeRect(px, y, w, h);
        x.strokeStyle = 'rgba(140,100,70,.10)'; x.lineWidth = 1; x.strokeRect(px + 4, y + 4, w - 8, h - 8);
      }
    }
    return texFromCanvas(cv, true);
  }
  function awningCanvas(kind) {
    const cv = document.createElement('canvas'); cv.width = 512; cv.height = 128;
    const x = cv.getContext('2d');
    const c1 = kind === 'plush' ? '#cf4530' : '#2b4050';
    const c2 = kind === 'plush' ? '#f3e2c6' : '#e8ddc8';
    for (let i = 0; i < 8; i++) { x.fillStyle = i % 2 ? c2 : c1; x.fillRect(i * 64, 0, 64, 128); }
    const sh = x.createLinearGradient(0, 0, 0, 128);
    sh.addColorStop(0, 'rgba(0,0,0,.05)'); sh.addColorStop(0.7, 'rgba(0,0,0,.25)'); sh.addColorStop(1, 'rgba(0,0,0,.55)');
    x.fillStyle = sh; x.fillRect(0, 0, 512, 128);
    return texFromCanvas(cv, false);
  }
  function signCanvas(text, kind) {
    const cv = document.createElement('canvas'); cv.width = 512; cv.height = 160;
    const x = cv.getContext('2d');
    x.fillStyle = '#f3e2c6'; x.fillRect(0, 0, 512, 160);
    x.strokeStyle = kind === 'plush' ? '#8a2f24' : '#2b3f63'; x.lineWidth = 10; x.strokeRect(7, 7, 498, 146);
    x.fillStyle = kind === 'plush' ? '#8a2f24' : '#2b3f63';
    x.font = 'bold 62px ' + FONT; x.textAlign = 'center'; x.textBaseline = 'middle';
    x.fillText(text, 256, 86);
    return texFromCanvas(cv, false);
  }
  function woodCanvas() {
    const cv = document.createElement('canvas'); cv.width = 256; cv.height = 256;
    const x = cv.getContext('2d');
    x.fillStyle = '#5a3a28'; x.fillRect(0, 0, 256, 256);
    for (let i = 0; i < 8; i++) {
      const px = i * 32;
      x.fillStyle = i % 2 ? 'rgba(120,80,54,.55)' : 'rgba(86,55,37,.55)';
      x.fillRect(px, 0, 32, 256);
      x.strokeStyle = 'rgba(28,16,10,.55)'; x.lineWidth = 3; x.beginPath(); x.moveTo(px, 0); x.lineTo(px, 256); x.stroke();
      x.strokeStyle = 'rgba(190,140,96,.10)'; x.lineWidth = 1;
      for (let g = 0; g < 5; g++) { x.beginPath(); x.moveTo(px + 5 + g * 5, 0); x.lineTo(px + 9 + g * 4, 256); x.stroke(); }
    }
    const sh = x.createLinearGradient(0, 0, 0, 256);
    sh.addColorStop(0, 'rgba(0,0,0,.05)'); sh.addColorStop(.75, 'rgba(0,0,0,.25)'); sh.addColorStop(1, 'rgba(0,0,0,.5)');
    x.fillStyle = sh; x.fillRect(0, 0, 256, 256);
    return texFromCanvas(cv, true);
  }
  function lanternCanvas() {
    const cv = document.createElement('canvas'); cv.width = 96; cv.height = 144;
    const x = cv.getContext('2d');
    const g = x.createRadialGradient(48, 60, 8, 48, 72, 70);
    g.addColorStop(0, 'rgba(255,240,190,1)'); g.addColorStop(0.35, 'rgba(255,176,86,1)'); g.addColorStop(0.8, 'rgba(198,70,34,.95)'); g.addColorStop(1, 'rgba(120,30,18,0)');
    x.fillStyle = g; x.beginPath(); x.ellipse(48, 72, 40, 54, 0, 0, Math.PI * 2); x.fill();
    x.fillStyle = '#3a2018'; x.fillRect(34, 8, 28, 12); x.fillRect(34, 124, 28, 12);
    return texFromCanvas(cv, false);
  }

  const TEX = {
    plushFront: texFromImage(shopArt('plush')),
    sushiFront: texFromImage(shopArt('sushi')),
    backdrop: texFromImage(backdropArt()),
    ground: groundCanvas(),
    wood: woodCanvas(),
    awningPlush: awningCanvas('plush'),
    awningSushi: awningCanvas('sushi'),
    signPlush: signCanvas('ぬいぐるみ', 'plush'),
    signSushi: signCanvas('鮨 小花', 'sushi'),
    lantern: lanternCanvas(),
    peds: []
  };
  // 行人文集
  const pedDefs = [
    { front: 'girl', back: 'girlBack', col: PED_COLORS[0] },
    { front: 'boy', back: 'boyBack', col: PED_COLORS[1] },
    { front: 'girl', back: 'girlBack', col: PED_COLORS[2] },
    { front: 'boy', back: 'boyBack', col: PED_COLORS[3] },
    { front: 'girl', back: 'girlBack', col: PED_COLORS[4] },
    { front: 'granny', back: 'girlBack', col: PED_COLORS[5], hair: '#cfc6c0' },
    { front: 'girl', back: 'girlBack', col: PED_COLORS[6] },
    { front: 'boy', back: 'boyBack', col: PED_COLORS[7] },
    { front: 'girl', back: 'girlBack', col: PED_COLORS[8] },
    { front: 'boy', back: 'boyBack', col: PED_COLORS[9] }
  ];
  pedDefs.forEach((d) => {
    TEX.peds.push({
      front: texFromImage(pedArt(d.front, d.col, d.hair)),
      back: texFromImage(pedArt(d.back, d.col, d.hair))
    });
  });

  /* --------------------------------- 场景 ---------------------------------- */
  const quads = [];       // 不透明/静态
  const sprites = [];     // 透明广告牌
  function addQuad(o) {
    quads.push({
      c: o.c, u: o.u, v: o.v,
      tex: o.tex || white, color: o.color || [1, 1, 1, 1],
      uv: o.uv || [1, 1]
    });
  }
  function addSprite(o) {
    sprites.push({ x: o.x, y: o.y, z: o.z, w: o.w, h: o.h, tex: o.tex, color: o.color || [1, 1, 1, 1], scale: o.scale || 1 });
  }

  // 地面
  addQuad({ c: [0, 0, -10], u: [42, 0, 0], v: [0, 0, -52], tex: TEX.ground, uv: [5, 10] });
  // 远景天幕
  addQuad({ c: [0, 11.5, -24], u: [44, 0, 0], v: [0, 23, 0], tex: TEX.backdrop, uv: [1, 1], color: [0.92, 0.92, 0.98, 1] });

  const WOOD = [0.62, 0.44, 0.33, 1];
  const WOOD_DARK = [0.36, 0.24, 0.18, 1];
  const ROOF = [0.30, 0.19, 0.14, 1];
  const COUNTER = [0.78, 0.55, 0.38, 1];

  function addShop(side, frontTex, awningTex, signTex, kind) {
    const shopStart = quads.length;
    const inner = side * 2.2;              // 营业面（朝街心）
    const center = side * 3.45;             // 盒子中心
    const depth = 1.5;                      // 东西向进深
    const len = 4.2;                        // 南北向长度
    const h = 3.35;                         // 高度
    const zc = 0;
    const outX = center + side * depth / 2;
    // 整间店绕“北侧内侧柱”向镜头方向偏 25°，营业面朝向街心偏南，南端墙退到外侧
    const yaw = side * 25 * Math.PI / 180;
    const cy = Math.cos(yaw), sy = Math.sin(yaw);
    const pivot = [inner, 0, -len / 2];
    const rotP = (p) => {
      const dx = p[0] - pivot[0], dz = p[2] - pivot[2];
      return [pivot[0] + dx * cy + dz * sy, p[1], pivot[2] - dx * sy + dz * cy];
    };
    const rotV = (v) => [v[0] * cy + v[2] * sy, v[1], -v[0] * sy + v[2] * cy];

    // 营业面：朝街心，U 沿街（z），V 向上
    addQuad({ c: [inner, h / 2, zc], u: [0, 0, len], v: [0, h, 0], tex: frontTex, color: [1, 1, 1, 1] });
    // 南侧端墙：朝镜头
    addQuad({ c: [center, h / 2, len / 2], u: [depth, 0, 0], v: [0, h, 0], tex: TEX.wood, color: WOOD });
    // 北侧端墙
    addQuad({ c: [center, h / 2, -len / 2], u: [-depth, 0, 0], v: [0, h, 0], tex: TEX.wood, color: WOOD_DARK });
    // 外侧墙
    addQuad({ c: [outX, h / 2, zc], u: [0, 0, -len], v: [0, h, 0], tex: TEX.wood, color: WOOD_DARK });
    // 屋顶
    addQuad({ c: [center, h, zc], u: [depth, 0, 0], v: [0, 0, -len], tex: null, color: ROOF });
    // 顶部后檐（给屋顶一点厚度）
    addQuad({ c: [center, h + 0.12, len / 2], u: [depth + 0.2, 0, 0], v: [0, 0.12, 0], tex: null, color: ROOF });

    // 柜台：从营业面伸进街道，有顶面/前脸/南端
    const cw = 0.55, ch = 0.95, clen = 3.8;
    const cx = inner - side * cw / 2;
    const cf = inner - side * cw;
    addQuad({ c: [cf, ch / 2, zc], u: [0, 0, clen], v: [0, ch, 0], tex: TEX.wood, color: COUNTER });
    addQuad({ c: [cx, ch, zc], u: [cw, 0, 0], v: [0, 0, -clen], tex: TEX.wood, color: [1.05, 0.82, 0.6, 1] });
    addQuad({ c: [cx, ch / 2, clen / 2], u: [cw, 0, 0], v: [0, ch, 0], tex: TEX.wood, color: [0.8, 0.6, 0.45, 1] });
    addQuad({ c: [cf, ch / 2, clen / 2], u: [0, 0, 0.05], v: [0, ch, 0], tex: null, color: [0.55, 0.36, 0.25, 1] });

    // 布棚：从营业面顶部斜挑向街心
    const aU = [0, 0, len + 0.3];
    const aV = [-side * 1.1, -0.55, 0];
    const ac = [inner - side * 1.1 / 2, h - 0.55 / 2 + 0.06, zc];
    addQuad({ c: ac, u: aU, v: aV, tex: awningTex, color: [1, 1, 1, 1] });
    // 棚沿下垂的一小段布
    addQuad({ c: [inner - side * 1.1, h - 0.62, zc], u: [0, 0, len + 0.3], v: [0, -0.16, 0], tex: awningTex, color: [0.9, 0.86, 0.8, 1] });

    // 南端招牌：朝镜头，最显眼
    addQuad({ c: [center, 2.62, len / 2 + 0.03], u: [depth * 0.86, 0, 0], v: [0, 0.78, 0], tex: signTex, color: [1, 1, 1, 1] });
    // 街心一侧的招牌（从街道上能看见）
    addQuad({ c: [inner - side * 0.06, 3.02, zc], u: [0, 0, 2.3], v: [0, 0.62, 0], tex: signTex, color: [0.9, 0.9, 0.9, 1] });

    // 南端小挑檐（朝镜头一侧的棚沿）
    addQuad({ c: [center, h - 0.12, len / 2 + 0.36], u: [depth + 0.35, 0, 0], v: [0, -0.28, 0.62], tex: awningTex, color: [0.94, 0.9, 0.86, 1] });

    // 四根柱子
    const px = inner - side * 0.06;
    [-len / 2 + 0.12, len / 2 - 0.12].forEach((pz) => {
      addQuad({ c: [px, h / 2, pz], u: [0.13, 0, 0], v: [0, h, 0], tex: null, color: [0.45, 0.28, 0.2, 1] });
      addQuad({ c: [px, h / 2, pz], u: [0, 0, 0.13], v: [0, h, 0], tex: null, color: [0.38, 0.23, 0.16, 1] });
    });

    // 把本店所有面绕内侧柱旋转
    for (let qi = shopStart; qi < quads.length; qi++) {
      const q = quads[qi];
      q.c = rotP(q.c); q.u = rotV(q.u); q.v = rotV(q.v);
    }
    // 侧灯/暖光位置
    const corners = [];
    [[inner, -len / 2], [outX, -len / 2], [inner, len / 2], [outX, len / 2]].forEach(([cx, cz]) => {
      [0, h].forEach((cy2) => corners.push(rotP([cx, cy2, cz])));
    });
    return { side, inner, center, len, h, corners };
  }

  const shops = [
    { kind: 'plush', ...addShop(-1, TEX.plushFront, TEX.awningPlush, TEX.signPlush, 'plush'), texFront: TEX.plushFront },
    { kind: 'sushi', ...addShop(1, TEX.sushiFront, TEX.awningSushi, TEX.signSushi, 'sushi'), texFront: TEX.sushiFront }
  ];

  // 灯笼广告牌
  const lanterns = [
    { x: -1.65, y: 4.15, z: -0.6 }, { x: 1.65, y: 4.15, z: -0.6 },
    { x: -0.9, y: 4.4, z: -3.8 }, { x: 0.9, y: 4.4, z: -3.8 }
  ];
  lanterns.forEach((l) => addSprite({ x: l.x, y: l.y, z: l.z, w: 0.4, h: 0.58, tex: TEX.lantern }));

  // 行人
  const PED_N = 16;
  const peds = [];
  for (let i = 0; i < PED_N; i++) {
    const variant = i % pedDefs.length;
    peds.push({
      x: -1.15 + Math.random() * 2.3,
      z: -9 + Math.random() * 13.4,
      dir: i % 2 ? 1 : -1,
      speed: 0.55 + Math.random() * 0.55,
      variant,
      texFront: TEX.peds[variant].front,
      texBack: TEX.peds[variant].back
    });
  }

  /* --------------------------------- 相机 ---------------------------------- */
  const cam = {
    yaw: 0, pitch: 0.09, dist: 10.2, baseDist: 10.2, focusDist: 6.8,
    target: [0, 1.42, -1.6],
    introT: 0, introFrom: { dist: 15, pitch: 0.30, ty: 2.0 }, introDur: 2.4,
    focus: null
  };
  let dragging = false, dragX = 0, dragY = 0, moved = 0, lastPointer = null;
  const clamp = (v, a, b) => Math.max(a, Math.min(b, v));

  function camEye() {
    const cp = Math.cos(cam.pitch), sp = Math.sin(cam.pitch);
    return [
      cam.target[0] + Math.sin(cam.yaw) * cp * cam.dist,
      cam.target[1] + sp * cam.dist,
      cam.target[2] + Math.cos(cam.yaw) * cp * cam.dist
    ];
  }

  canvas.addEventListener('pointerdown', (e) => {
    if (app.classList.contains('is-detail')) return;
    dragging = true; moved = 0; dragX = e.clientX; dragY = e.clientY; lastPointer = e.pointerId;
    canvas.setPointerCapture(e.pointerId);
    viewport.classList.add('is-dragging');
  });
  canvas.addEventListener('pointermove', (e) => {
    if (!dragging || e.pointerId !== lastPointer) return;
    const dx = e.clientX - dragX, dy = e.clientY - dragY;
    dragX = e.clientX; dragY = e.clientY; moved += Math.abs(dx) + Math.abs(dy);
    if (moved > 5) {
      cam.yaw = clamp(cam.yaw - dx * 0.004, -0.55, 0.55);
      cam.pitch = clamp(cam.pitch + dy * 0.003, 0.02, 0.46);
    }
  });
  function endPointer(e) {
    if (!dragging) return;
    dragging = false;
    viewport.classList.remove('is-dragging');
    if (lastPointer !== null && canvas.hasPointerCapture(lastPointer)) canvas.releasePointerCapture(lastPointer);
    lastPointer = null;
    if (moved < 8 && e && e.type === 'pointerup') hitTest(e.clientX, e.clientY);
  }
  canvas.addEventListener('pointerup', endPointer);
  canvas.addEventListener('pointercancel', endPointer);
  canvas.addEventListener('wheel', (e) => {
    if (app.classList.contains('is-detail')) return;
    e.preventDefault();
    cam.dist = clamp(cam.dist * (1 + e.deltaY * 0.0012), 4.8, 13.5);
  }, { passive: false });
  canvas.addEventListener('dblclick', () => { if (!app.classList.contains('is-detail')) resetView(); });

  /* ------------------------------- 命中/交互 -------------------------------- */
  let currentVP = null;
  function projectShopBox(shop) {
    if (!currentVP) return null;
    const pts = [];
    (shop.corners || []).forEach((p3) => {
      const p = projectPoint(currentVP, p3);
      if (p) pts.push(p);
    });
    if (!pts.length) return null;
    let minX = 1e9, maxX = -1e9, minY = 1e9, maxY = -1e9;
    pts.forEach((p) => { minX = Math.min(minX, p[0]); maxX = Math.max(maxX, p[0]); minY = Math.min(minY, p[1]); maxY = Math.max(maxY, p[1]); });
    return { minX, maxX, minY, maxY };
  }
  function hitTest(clientX, clientY) {
    const rect = canvas.getBoundingClientRect();
    const nx = ((clientX - rect.left) / rect.width) * 2 - 1;
    const ny = -(((clientY - rect.top) / rect.height) * 2 - 1);
    // 先用左/右两店的投影包围盒（商店在左右，互不重叠）
    for (const shop of shops) {
      const b = shop.screenBox;
      if (!b) continue;
      if (nx >= b.minX && nx <= b.maxX && ny >= b.minY && ny <= b.maxY) {
        if (window.__openDetail) window.__openDetail(shop.kind);
        return;
      }
    }
  }

  /* -------------------------------- 渲染 ----------------------------------- */
  function resize() {
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    const w = viewport.clientWidth || window.innerWidth;
    const h = viewport.clientHeight || window.innerHeight;
    canvas.width = Math.floor(w * dpr);
    canvas.height = Math.floor(h * dpr);
    canvas.style.width = w + 'px';
    canvas.style.height = h + 'px';
    const portrait = h > w * 1.08;
    cam.baseDist = portrait ? 13.8 : 10.2;
    cam.focusDist = portrait ? 8.2 : 6.8;
    cam.introFrom.dist = cam.baseDist + 4.2;
    gl.viewport(0, 0, canvas.width, canvas.height);
  }
  window.addEventListener('resize', resize);
  resize();

  const FOG = [0.12, 0.09, 0.19];
  const startT = performance.now();
  let lastT = startT;

  function updateCamera(t) {
    const intro = clamp((t - startT) / 1000 / cam.introDur, 0, 1);
    if (intro < 1) {
      const e = 1 - Math.pow(1 - intro, 3);
      cam.dist = cam.introFrom.dist + (cam.baseDist - cam.introFrom.dist) * e;
      cam.pitch = cam.introFrom.pitch + (0.09 - cam.introFrom.pitch) * e;
      cam.target[1] = cam.introFrom.ty + (1.42 - cam.introFrom.ty) * e;
    } else if (cam.focus) {
      const f = cam.focus;
      cam.target[0] += (f.x - cam.target[0]) * 0.12;
      cam.target[1] += (f.y - cam.target[1]) * 0.12;
      cam.target[2] += (f.z - cam.target[2]) * 0.12;
      cam.dist += (f.dist - cam.dist) * 0.12;
    } else {
      cam.target[0] += (0 - cam.target[0]) * 0.10;
      cam.target[1] += (1.42 - cam.target[1]) * 0.10;
      cam.target[2] += (-1.6 - cam.target[2]) * 0.10;
      cam.dist += (cam.baseDist - cam.dist) * 0.10;
    }
  }

  function updatePeds(dt) {
    for (const p of peds) {
      p.z += p.dir * p.speed * dt;
      if (p.z > 4.4) { p.z = 4.4; p.dir = -1; }
      if (p.z < -9.2) { p.z = -9.2; p.dir = 1; }
      p.x += (Math.sin(p.z * 0.8 + p.variant) * 0.12) * dt;
      p.x = clamp(p.x, -1.15, 1.15);
    }
  }

  function drawQuad(q, view, proj, eye, billboard) {
    let Ux, Uy, Uz, Vx, Vy, Vz;
    if (billboard) {
      const fwd = v3.norm(v3.sub(cam.target, eye));
      const right = v3.norm(v3.cross(fwd, [0, 1, 0]));
      const up = v3.cross(right, fwd);
      Ux = right[0] * q.w; Uy = right[1] * q.w; Uz = right[2] * q.w;
      Vx = up[0] * q.h; Vy = up[1] * q.h; Vz = up[2] * q.h;
    } else {
      Ux = q.u[0]; Uy = q.u[1]; Uz = q.u[2];
      Vx = q.v[0]; Vy = q.v[1]; Vz = q.v[2];
    }
    const n = v3.norm(v3.cross([Ux, Uy, Uz], [Vx, Vy, Vz]));
    const model = new Float32Array([
      Ux, Uy, Uz, 0,
      Vx, Vy, Vz, 0,
      n[0], n[1], n[2], 0,
      q.c[0], q.c[1], q.c[2], 1
    ]);
    gl.uniformMatrix4fv(U.uModel, false, model);
    gl.uniformMatrix4fv(U.uView, false, view);
    gl.uniformMatrix4fv(U.uProj, false, proj);
    gl.uniform2fv(U.uUVScale, q.uv || [1, 1]);
    gl.uniform4fv(U.uColor, q.color || [1, 1, 1, 1]);
    gl.uniform3fv(U.uCamPos, eye);
    gl.uniform3fv(U.uFogColor, FOG);
    gl.uniform1f(U.uFogNear, 18);
    gl.uniform1f(U.uFogFar, 46);
    gl.activeTexture(gl.TEXTURE0);
    gl.bindTexture(gl.TEXTURE_2D, q.tex || white);
    gl.uniform1i(U.uTex, 0);
    gl.drawElements(gl.TRIANGLES, 6, gl.UNSIGNED_SHORT, 0);
  }

  function frame(now) {
    const t = now || performance.now();
    const dt = Math.min(0.05, Math.max(0, (t - lastT) / 1000));
    lastT = t;
    updateCamera(t);
    updatePeds(dt);

    gl.clearColor(FOG[0], FOG[1], FOG[2], 1);
    gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);
    gl.enable(gl.DEPTH_TEST);
    gl.depthFunc(gl.LEQUAL);
    gl.disable(gl.BLEND);
    gl.disable(gl.CULL_FACE);
    gl.useProgram(prog);
    gl.bindBuffer(gl.ARRAY_BUFFER, quadBuf);
    gl.enableVertexAttribArray(A.pos);
    gl.vertexAttribPointer(A.pos, 3, gl.FLOAT, false, 20, 0);
    gl.enableVertexAttribArray(A.uv);
    gl.vertexAttribPointer(A.uv, 2, gl.FLOAT, false, 20, 12);
    gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, idxBuf);

    const eye = camEye();
    const view = lookAt(eye, cam.target, [0, 1, 0]);
    const proj = perspective(54 * Math.PI / 180, canvas.width / canvas.height, 0.1, 120);
    const vp = mul4(proj, view);
    currentVP = vp;

    // 不透明
    for (const q of quads) drawQuad(q, view, proj, eye, false);

    // 商店的屏幕包围盒（用于点击）
    shops.forEach((s) => { s.screenBox = projectShopBox(s); });

    // 透明：行人 + 灯笼，按距离排序
    const list = [];
    for (const p of peds) {
      list.push({ kind: 'ped', ref: p, d: (p.x - eye[0]) ** 2 + (0.9 - eye[1]) ** 2 + (p.z - eye[2]) ** 2 });
    }
    for (const l of sprites) {
      list.push({ kind: 'sprite', ref: l, d: (l.x - eye[0]) ** 2 + (l.y - eye[1]) ** 2 + (l.z - eye[2]) ** 2 });
    }
    list.sort((a, b) => b.d - a.d);
    gl.enable(gl.BLEND);
    gl.blendFunc(gl.SRC_ALPHA, gl.ONE_MINUS_SRC_ALPHA);
    gl.depthMask(false);
    for (const item of list) {
      if (item.kind === 'ped') {
        const p = item.ref;
        const tex = p.dir > 0 ? p.texFront : p.texBack;
        drawQuad({ w: 0.72, h: 1.78, c: [p.x, 0.89, p.z], tex, color: [1, 1, 1, 1] }, view, proj, eye, true);
      } else {
        const l = item.ref;
        drawQuad({ w: l.w, h: l.h, c: [l.x, l.y, l.z], tex: l.tex, color: [1, 1, 1, 1] }, view, proj, eye, true);
      }
    }
    gl.depthMask(true);
    gl.disable(gl.BLEND);

    requestAnimationFrame(frame);
  }

  /* ------------------------------- 对外接口 -------------------------------- */
  function focusShop(kind) {
    const shop = shops.find((s) => s.kind === kind);
    if (!shop) return;
    cam.focus = { x: shop.inner - shop.side * 0.9, y: 1.7, z: 0.4, dist: cam.focusDist };
  }
  function resetView() { cam.focus = null; }
  window.Scene3D = { focusShop, resetView };

  requestAnimationFrame(frame);
})();
